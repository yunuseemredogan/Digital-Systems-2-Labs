/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/Digital Systems 2 Lab/EEM334-Lab3 VHD Files/LAB-3-FINAL-FINAL-FINAL/LAB-3-FINAL-FINAL-FINAL/Find_Y.vhd";
extern char *IEEE_P_3620187407;



static void work_a_4054289797_3212880686_p_0(char *t0)
{
    char t5[16];
    char t19[16];
    char t32[16];
    char t45[16];
    char t58[16];
    char t71[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t20;
    char *t21;
    int t22;
    unsigned char t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t33;
    char *t34;
    int t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t46;
    char *t47;
    int t48;
    unsigned char t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t59;
    char *t60;
    int t61;
    unsigned char t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t72;
    char *t73;
    int t74;
    unsigned char t75;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;

LAB0:    xsi_set_current_line(17, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 2948U);
    t3 = (t0 + 2976);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:    t15 = (t0 + 592U);
    t16 = *((char **)t15);
    t15 = (t0 + 2948U);
    t17 = (t0 + 2980);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 3;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (3 - 0);
    t9 = (t22 * 1);
    t9 = (t9 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t9;
    t23 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t16, t15, t17, t19);
    if (t23 != 0)
        goto LAB5;

LAB6:    t28 = (t0 + 592U);
    t29 = *((char **)t28);
    t28 = (t0 + 2948U);
    t30 = (t0 + 2984);
    t33 = (t32 + 0U);
    t34 = (t33 + 0U);
    *((int *)t34) = 0;
    t34 = (t33 + 4U);
    *((int *)t34) = 3;
    t34 = (t33 + 8U);
    *((int *)t34) = 1;
    t35 = (3 - 0);
    t9 = (t35 * 1);
    t9 = (t9 + 1);
    t34 = (t33 + 12U);
    *((unsigned int *)t34) = t9;
    t36 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t29, t28, t30, t32);
    if (t36 != 0)
        goto LAB7;

LAB8:    t41 = (t0 + 592U);
    t42 = *((char **)t41);
    t41 = (t0 + 2948U);
    t43 = (t0 + 2988);
    t46 = (t45 + 0U);
    t47 = (t46 + 0U);
    *((int *)t47) = 0;
    t47 = (t46 + 4U);
    *((int *)t47) = 3;
    t47 = (t46 + 8U);
    *((int *)t47) = 1;
    t48 = (3 - 0);
    t9 = (t48 * 1);
    t9 = (t9 + 1);
    t47 = (t46 + 12U);
    *((unsigned int *)t47) = t9;
    t49 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t42, t41, t43, t45);
    if (t49 != 0)
        goto LAB9;

LAB10:    t54 = (t0 + 592U);
    t55 = *((char **)t54);
    t54 = (t0 + 2948U);
    t56 = (t0 + 2992);
    t59 = (t58 + 0U);
    t60 = (t59 + 0U);
    *((int *)t60) = 0;
    t60 = (t59 + 4U);
    *((int *)t60) = 3;
    t60 = (t59 + 8U);
    *((int *)t60) = 1;
    t61 = (3 - 0);
    t9 = (t61 * 1);
    t9 = (t9 + 1);
    t60 = (t59 + 12U);
    *((unsigned int *)t60) = t9;
    t62 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t55, t54, t56, t58);
    if (t62 != 0)
        goto LAB11;

LAB12:    t67 = (t0 + 592U);
    t68 = *((char **)t67);
    t67 = (t0 + 2948U);
    t69 = (t0 + 2996);
    t72 = (t71 + 0U);
    t73 = (t72 + 0U);
    *((int *)t73) = 0;
    t73 = (t72 + 4U);
    *((int *)t73) = 3;
    t73 = (t72 + 8U);
    *((int *)t73) = 1;
    t74 = (3 - 0);
    t9 = (t74 * 1);
    t9 = (t9 + 1);
    t73 = (t72 + 12U);
    *((unsigned int *)t73) = t9;
    t75 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t68, t67, t69, t71);
    if (t75 != 0)
        goto LAB13;

LAB14:
LAB15:    t80 = (t0 + 1584);
    t81 = (t80 + 32U);
    t82 = *((char **)t81);
    t83 = (t82 + 40U);
    t84 = *((char **)t83);
    *((unsigned char *)t84) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t80);

LAB2:    t85 = (t0 + 1540);
    *((int *)t85) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1584);
    t11 = (t7 + 32U);
    t12 = *((char **)t11);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t21 = (t0 + 1584);
    t24 = (t21 + 32U);
    t25 = *((char **)t24);
    t26 = (t25 + 40U);
    t27 = *((char **)t26);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t21);
    goto LAB2;

LAB7:    t34 = (t0 + 1584);
    t37 = (t34 + 32U);
    t38 = *((char **)t37);
    t39 = (t38 + 40U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t34);
    goto LAB2;

LAB9:    t47 = (t0 + 1584);
    t50 = (t47 + 32U);
    t51 = *((char **)t50);
    t52 = (t51 + 40U);
    t53 = *((char **)t52);
    *((unsigned char *)t53) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t47);
    goto LAB2;

LAB11:    t60 = (t0 + 1584);
    t63 = (t60 + 32U);
    t64 = *((char **)t63);
    t65 = (t64 + 40U);
    t66 = *((char **)t65);
    *((unsigned char *)t66) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t60);
    goto LAB2;

LAB13:    t73 = (t0 + 1584);
    t76 = (t73 + 32U);
    t77 = *((char **)t76);
    t78 = (t77 + 40U);
    t79 = *((char **)t78);
    *((unsigned char *)t79) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB16:    goto LAB2;

}


extern void work_a_4054289797_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4054289797_3212880686_p_0};
	xsi_register_didat("work_a_4054289797_3212880686", "isim/Top_isim_beh.exe.sim/work/a_4054289797_3212880686.didat");
	xsi_register_executes(pe);
}
